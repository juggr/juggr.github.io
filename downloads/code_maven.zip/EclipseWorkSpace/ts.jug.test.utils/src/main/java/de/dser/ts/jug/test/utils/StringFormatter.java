package de.dser.ts.jug.test.utils;

public class StringFormatter {
	public String format(String message) {
		return message.toLowerCase();
	}
}
