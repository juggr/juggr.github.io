package de.dser.ts.jug.test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class EvenCheckerTest {

	EvenChecker checker;
	@Before
	public void setUp(){
	checker = new EvenChecker();
	}

	@Test
	public void testEven_True() throws Exception {
	long value = 12l;
	boolean isEven = checker.isEven(value);
	Assert.assertTrue(isEven);
	}

	@Test
	public void testEven_False() throws Exception {
	long value = 11l;
	boolean isEven = checker.isEven(value);
	Assert.assertFalse(isEven);
	}


}
