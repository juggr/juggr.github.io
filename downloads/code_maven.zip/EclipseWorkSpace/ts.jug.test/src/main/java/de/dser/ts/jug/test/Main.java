/**
 * 
 */
package de.dser.ts.jug.test;

import de.dser.ts.jug.test.utils.StringFormatter;

/**
 * @author thomas.storch
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String message = "HaLlO WeLt";
		message = new StringFormatter().format(message);
		System.out.println(message);
	}

}
