package de.dser.ts.jug.test;

public class EvenChecker {
	public boolean isEven(long value) {
		long modulo = value % 2;
		boolean isEven = (modulo == 0);
		return isEven;
}

}
