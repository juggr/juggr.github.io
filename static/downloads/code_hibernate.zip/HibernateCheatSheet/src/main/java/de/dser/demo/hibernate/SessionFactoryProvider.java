package de.dser.demo.hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import de.dser.demo.hibernate.model.JavaUserGroup;
import de.dser.demo.hibernate.model.Meeting;
import de.dser.demo.hibernate.model.MeetingTopic;
import de.dser.demo.hibernate.model.Member;

public class SessionFactoryProvider {

	public SessionFactory buildSessionFactory() {
		AnnotationConfiguration hibernateConfig = new AnnotationConfiguration();
		hibernateConfig.configure();
		
		hibernateConfig.addAnnotatedClass(JavaUserGroup.class);
		hibernateConfig.addAnnotatedClass(Member.class);
		hibernateConfig.addAnnotatedClass(Meeting.class);
		hibernateConfig.addAnnotatedClass(MeetingTopic.class);
		
		SessionFactory sessionFactory = hibernateConfig.buildSessionFactory();
		return sessionFactory;
	}
}
