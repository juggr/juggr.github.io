package de.dser.demo.hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.hsqldb.util.DatabaseManagerSwing;

import de.dser.demo.hibernate.model.JavaUserGroup;

public class DemoProgramHibernate {
	public static void main(String[] args) {
		Session session = setupSession();
		
		Transaction transaction = session.beginTransaction();
		
		JavaUserGroup javaUserGroup = new JavaUserGroup();
		javaUserGroup.setGroupName("jug g�rlitz");
		session.persist(javaUserGroup);
		transaction.commit();
		
		System.out.println("persisted!");
		
		
		DatabaseManagerSwing
		.main(new String[] {
				"--url",
				"jdbc:hsqldb:mem:test"});
	}

	private static Session setupSession() {
		SessionFactory sessionFactory = new SessionFactoryProvider().buildSessionFactory();
		Session session = sessionFactory.openSession();
		return session;
		
	}

	 
}
