package de.dser.demo.hibernate.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="member")
@org.hibernate.annotations.Table(appliesTo="member", comment="java user-group member")
public class Member extends PersistenceClass {
	private String firstName;
	private String lastName;
	private Set<JavaUserGroup> groupsToVisit;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	@ManyToMany
	public Set<JavaUserGroup> getGroupsToVisit() {
		return groupsToVisit;
	}
	public void setGroupsToVisit(Set<JavaUserGroup> groupsToVisit) {
		this.groupsToVisit = groupsToVisit;
	}
	
}
