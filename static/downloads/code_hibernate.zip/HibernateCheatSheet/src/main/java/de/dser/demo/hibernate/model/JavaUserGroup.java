package de.dser.demo.hibernate.model;

import java.util.Calendar;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name="java_user_group")
@org.hibernate.annotations.Table(appliesTo="java_user_group", comment="Haupttabelle der User-Group")
public class JavaUserGroup extends PersistenceClass {
	private String groupName;
	private Calendar foundingDate;
	private Set<Member> members;
	private Set<Meeting> meetings;
	
	@Column(nullable=false)
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	@Temporal(TemporalType.TIMESTAMP)
	public Calendar getFoundingDate() {
		return foundingDate;
	}
	public void setFoundingDate(Calendar foundingDate) {
		this.foundingDate = foundingDate;
	}
	@ManyToMany(mappedBy="groupsToVisit")
	public Set<Member> getMembers() {
		return members;
	}
	public void setMembers(Set<Member> members) {
		this.members = members;
	}
	@OneToMany(mappedBy="javaUserGroup")
	public Set<Meeting> getMeetings() {
		return meetings;
	}
	public void setMeetings(Set<Meeting> meetings) {
		this.meetings = meetings;
	}	
}
