package de.dser.demo.dto.MemberTopic;

import java.util.Calendar;
import java.util.Date;

public class MemberTopic {
	private String NAME;
	private String TOPIC;
	private Date DATE;
	public String getNAME() {
		return NAME;
	}
	public void setNAME(String nAME) {
		NAME = nAME;
	}
	public String getTOPIC() {
		return TOPIC;
	}
	public void setTOPIC(String tOPIC) {
		TOPIC = tOPIC;
	}
	public Date getDATE() {
		return DATE;
	}
	public void setDATE(Date dATE) {
		DATE = dATE;
	}
	
	
}
