package de.dser.demo.hibernate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="meeting_topics")
@org.hibernate.annotations.Table(appliesTo="meeting_topics", comment="Themen w�hrend eines Java-User-Group Abends")
public class MeetingTopic extends PersistenceClass {

	private Member presenter;
	private String topic;
	private String briefDescription;

	@ManyToOne(optional=false)
	public Member getPresenter() {
		return presenter;
	}
	public void setPresenter(Member presenter) {
		this.presenter = presenter;
	}
	@Column(nullable=false)
	public String getTopic(){
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	@Column(nullable=false)
	public String getBriefDescription() {
		return briefDescription;
	}
	public void setBriefDescription(String briefDescription) {
		this.briefDescription = briefDescription;
	}
}
