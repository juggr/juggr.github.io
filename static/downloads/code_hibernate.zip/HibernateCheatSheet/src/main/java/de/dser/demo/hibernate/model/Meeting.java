package de.dser.demo.hibernate.model;

import java.util.Calendar;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="meetings")
@org.hibernate.annotations.Table(appliesTo="meetings", comment="Treffen der User-Group")
public class Meeting extends PersistenceClass {
	private Calendar date;
	private Member moderator;
	private JavaUserGroup javaUserGroup;
	private Set<MeetingTopic> meetingTopics;
	
	@Temporal(TemporalType.TIMESTAMP)
	public Calendar getDate() {
		return date;
	}
	public void setDate(Calendar date) {
		this.date = date;
	}
	@ManyToOne(optional=false)
	public Member getModerator() {
		return moderator;
	}
	public void setModerator(Member moderator) {
		this.moderator = moderator;
	}
	@ManyToOne(optional=false)
	public JavaUserGroup getJavaUserGroup() {
		return javaUserGroup;
	}
	public void setJavaUserGroup(JavaUserGroup javaUserGroup) {
		this.javaUserGroup = javaUserGroup;
	}
	@OneToMany
	@JoinColumn(name="meeting_id")
	public Set<MeetingTopic> getMeetingTopics() {
		return meetingTopics;
	}
	public void setMeetingTopics(Set<MeetingTopic> meetingTopics) {
		this.meetingTopics = meetingTopics;
	}
}
