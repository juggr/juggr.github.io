package de.dser.demo.hibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hsqldb.util.DatabaseManagerSwing;

import de.dser.demo.hibernate.model.JavaUserGroup;

public class DemoProgrammJPA {
	
	public static void main(String[] args) {
		EntityManager entityManager = setupHibernate();
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		
		JavaUserGroup jug = new JavaUserGroup();
		jug.setGroupName("group Name");		
		entityManager.persist(jug);
		
		transaction.commit();
		
		System.out.println("persisted!");

		DatabaseManagerSwing
		.main(new String[] {
				"--url",
				"jdbc:hsqldb:mem:test"});
		
	}

	private static EntityManager setupHibernate() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("manager1");
		
		EntityManager entityManager = emf.createEntityManager();
		
		System.out.println("got entityManager: " + entityManager);
		
		return entityManager;
	}
}
