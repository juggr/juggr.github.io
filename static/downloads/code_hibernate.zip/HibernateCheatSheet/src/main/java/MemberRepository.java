import java.util.List;

import org.hibernate.Session;

import de.dser.demo.hibernate.model.Member;


public class MemberRepository {

	private final Session session;

	public MemberRepository(Session session) {
		this.session = session;
	}
	public List<Member> findMemberyByName(String name) {
		String hql = "from Member where lower(firstName) like :searchname or lower(lastName) like :searchname";
		
		String likePattern = "%" + name + "%";
		return (List<Member>)session.createQuery(hql)
				.setString("searchname", likePattern)
				.list();
	}
}
