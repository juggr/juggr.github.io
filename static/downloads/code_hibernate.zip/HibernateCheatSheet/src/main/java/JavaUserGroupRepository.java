import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import de.dser.demo.hibernate.model.JavaUserGroup;


public class JavaUserGroupRepository {

	private final Session session;

	public JavaUserGroupRepository(Session session) {
		this.session = session;
	}
	
	public List<JavaUserGroup> findGroupsOfMember(Long memberId) {
		return (List<JavaUserGroup>)session.createCriteria(JavaUserGroup.class)
		.createCriteria("members")
		.add(Restrictions.idEq(memberId))
		.list();
	}
	
}
