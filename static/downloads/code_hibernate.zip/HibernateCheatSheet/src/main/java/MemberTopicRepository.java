import java.util.List;

import org.hibernate.Session;
import org.hibernate.transform.AliasToBeanResultTransformer;

import de.dser.demo.dto.MemberTopic.MemberTopic;


public class MemberTopicRepository {

	private final Session session;

	public MemberTopicRepository(Session session) {
		this.session = session;
	}
	
	public List<MemberTopic> findTopicsOfUserGroup(Long userGroupId) {
		String sql = "select MEMBER.FIRSTNAME as name, MEETING_TOPICS.TOPIC as topic, MEETINGS.DATE as date from JAVA_USER_GROUP"+
						" join MEETINGS on MEETINGS.JAVAUSERGROUP_ID = JAVA_USER_GROUP.ID"+
						" join MEETING_TOPICS on MEETING_TOPICS.MEETING_ID = MEETINGS.ID"+
						" join MEMBER on MEETING_TOPICS.PRESENTER_ID = MEMBER.ID"+
						" where JAVA_USER_GROUP.id = 1";
		return (List<MemberTopic>)session.createSQLQuery(sql)
		.setResultTransformer(new AliasToBeanResultTransformer(MemberTopic.class))
		.list();
	}
}
