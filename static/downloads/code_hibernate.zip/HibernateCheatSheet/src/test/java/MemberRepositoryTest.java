import static org.junit.Assert.*;

import java.util.List;

import junit.framework.Assert;

import org.hibernate.Session;
import org.junit.Test;

import de.dser.demo.hibernate.model.DatabaseTestBase;
import de.dser.demo.hibernate.model.Member;


public class MemberRepositoryTest extends DatabaseTestBase {

	@Test
	public void test() {
		Session session = buildSessionFactory.openSession();
		setupData(session);
		
		List<Member> membersFound = new MemberRepository(session)
		.findMemberyByName("uhr");
		
		Assert.assertEquals(1, membersFound.size());
		Assert.assertEquals("Dieter", membersFound.get(0).getFirstName());
	}

	private void setupData(Session session) {
		session.beginTransaction();
		
		Member member = new Member();
		member.setFirstName("Marko");
		member.setLastName("Modsching");
		session.persist(member);
		
		Member member2 = new Member();
		member2.setFirstName("Dieter");
		member2.setLastName("Nuhr");
		session.persist(member2);
		
		session.flush();
		session.getTransaction().commit();
		session.clear();
		
		
		session.beginTransaction();
		Assert.assertEquals(2, session.createCriteria(Member.class).list().size());
		session.getTransaction().commit();
		session.clear();
	}

}
