import static org.junit.Assert.*;

import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import junit.framework.Assert;

import org.hibernate.Session;
import org.junit.Test;

import de.dser.demo.dto.MemberTopic.MemberTopic;
import de.dser.demo.hibernate.model.DatabaseTestBase;
import de.dser.demo.hibernate.model.JavaUserGroup;
import de.dser.demo.hibernate.model.Meeting;
import de.dser.demo.hibernate.model.MeetingTopic;
import de.dser.demo.hibernate.model.Member;


public class MemberTopicRepositoryTest extends DatabaseTestBase{

	private JavaUserGroup jug;

	@Test
	public void test() {
		Session session = buildSessionFactory.openSession();
		setupData(session);
		
		List<MemberTopic> topics = new MemberTopicRepository(session)
		.findTopicsOfUserGroup(jug.getId());

		Assert.assertEquals(2, topics.size());
		for (MemberTopic memberTopic : topics) {
			System.out.println(MessageFormat.format("{0} pr�sentierte am {1, date,dd.MM.yyyy} das Thema {2}", 
					memberTopic.getNAME(), 
					memberTopic.getDATE(), 
					memberTopic.getTOPIC()));
		}
	}

	private void setupData(Session session) {
		session.beginTransaction();
		
		jug = new JavaUserGroup();
		jug.setGroupName("JUG G�rlitz");
		jug.setFoundingDate(GregorianCalendar.getInstance());
		session.persist(jug);
		
		Member m1 = new Member();
		m1.setFirstName("Marek");
		m1.setLastName("Wester");
		m1.setGroupsToVisit(createGroupsSet(jug));
		session.persist(m1);
		
		Member m2 = new Member();
		m2.setFirstName("Richard");
		m2.setLastName("Hauswald");
		m2.setGroupsToVisit(createGroupsSet(jug));
		session.persist(m2);
		
		MeetingTopic mt1 = new MeetingTopic();
		mt1.setBriefDescription("Einf�hrung der neuen JavaUserGroup in G�rlitz!");
		mt1.setTopic("Einf�hrung");
		mt1.setPresenter(m1);
		session.persist(mt1);
		
		MeetingTopic mt2 = new MeetingTopic();
		mt2.setBriefDescription("Mocking mit Easy-Mock!");
		mt2.setTopic("Mocking mit Easy-Mock");
		mt2.setPresenter(m2);
		session.persist(mt2);
		
		Set<MeetingTopic> topics = new HashSet<MeetingTopic>();
		topics.add(mt1);
		topics.add(mt2);
		
		Meeting meeting1 = new Meeting();
		meeting1.setDate(parseDate("2011-01-01"));
		meeting1.setJavaUserGroup(jug);
		meeting1.setMeetingTopics(topics);
		meeting1.setModerator(m2);
		session.persist(meeting1);
		
		session.flush();
		session.getTransaction().commit();
		session.clear();
		
		session.beginTransaction();
		Assert.assertEquals(1, session.createCriteria(JavaUserGroup.class).list().size());
		Assert.assertEquals(2, session.createCriteria(Member.class).list().size());
		Assert.assertEquals(2, session.createCriteria(MeetingTopic.class).list().size());
		Assert.assertEquals(1, session.createCriteria(Meeting.class).list().size());

		session.clear();
	}

	private Calendar parseDate(String string) {
		try {
			Date date = new SimpleDateFormat("yyyy-MM-dd").parse(string);
			Calendar cal = GregorianCalendar.getInstance();
			cal.setTime(date);
			return cal;
		} catch (ParseException e) {
			throw new RuntimeException("Setup-Failure! Invalid Date:" + string);
		}
	}

	private Set<JavaUserGroup> createGroupsSet(JavaUserGroup ... jug) {
		Set<JavaUserGroup> groups = new HashSet<JavaUserGroup>();
		for (JavaUserGroup javaUserGroup : jug) {
			groups.add(javaUserGroup);
		}
		
		return groups;
	}

}
