import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import junit.framework.Assert;

import org.hibernate.Session;
import org.junit.Test;

import de.dser.demo.hibernate.model.DatabaseTestBase;
import de.dser.demo.hibernate.model.JavaUserGroup;
import de.dser.demo.hibernate.model.Member;


public class JavaUserGroupRepositoryTest extends DatabaseTestBase {
	private Member m1;

	@Test
	public void test() {
		Session session = buildSessionFactory.openSession();
		setupData(session);
		
		List<JavaUserGroup> groupsOfMember = new JavaUserGroupRepository(session)
		.findGroupsOfMember(m1.getId());
		Assert.assertEquals(2, groupsOfMember.size());
	}

	private void setupData(Session session) {
		session.beginTransaction();
		
		JavaUserGroup jug1 = new JavaUserGroup();
		jug1.setGroupName("Dresden");
		session.persist(jug1);
		
		JavaUserGroup jug2 = new JavaUserGroup();
		jug2.setGroupName("Dresden");
		session.persist(jug2);
		
		m1 = new Member();
		m1.setFirstName("Marko");
		m1.setLastName("Modsching");
		
		Set<JavaUserGroup> groupsToVisit = new HashSet<JavaUserGroup>();
		groupsToVisit.add(jug1);
		groupsToVisit.add(jug2);		
		m1.setGroupsToVisit(groupsToVisit);
		session.persist(m1);
		
		session.flush();
		session.getTransaction().commit();
		session.clear();
		
		session.beginTransaction();
		Assert.assertEquals(2, session.createCriteria(JavaUserGroup.class).list().size());
		session.getTransaction().commit();
		session.clear();
	}
}
