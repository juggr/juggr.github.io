package de.dser.demo.hibernate.model;

import junit.framework.Assert;

import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.dser.demo.hibernate.SessionFactoryProvider;

public class JavaUserGroupTest {

	private SessionFactory buildSessionFactory;
	@Before
	public void setup() {
		buildSessionFactory = new SessionFactoryProvider().buildSessionFactory();
	}
	@After
	public void teardown() {
		if( buildSessionFactory != null )
			buildSessionFactory.close();
	}
	@Test
	public void test() {
		Session session = buildSessionFactory.openSession();
		setupTestData(session);
		
		session.close();
		
	}
	private void setupTestData(Session session) {
		session.beginTransaction();
		JavaUserGroup jug = new JavaUserGroup();
		jug.setGroupName("g�rlitz");
		
		session.persist(jug);
		session.flush();
		session.getTransaction().commit();
		session.clear();
		
		session.beginTransaction();
		Assert.assertEquals(1, session.createCriteria(JavaUserGroup.class).list().size());
		session.clear();
		
		
		
	}

}
