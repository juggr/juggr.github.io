package de.dser.demo.hibernate.model;

import static org.junit.Assert.*;

import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class MemberPersistenceTest extends DatabaseTestBase {

	
	
	@Test
	public void test() {
		Session session = buildSessionFactory.openSession();
		setupData(session);
	}

	private void setupData(Session session) {
		session.beginTransaction();
		
		JavaUserGroup jug1 = new JavaUserGroup();
		jug1.setGroupName("G�rlitz");
		jug1.setFoundingDate(GregorianCalendar.getInstance());
		session.persist(jug1);
		
		JavaUserGroup jug2 = new JavaUserGroup();
		jug2.setFoundingDate(GregorianCalendar.getInstance());
		jug2.setGroupName("Dresden");
		session.persist(jug2);
		
		Member m1 = new Member();
		m1.setFirstName("Marko");
		m1.setLastName("Modsching");
		Set<JavaUserGroup> groupsToVisit = new HashSet<JavaUserGroup>();
		groupsToVisit.add(jug1);
		groupsToVisit.add(jug2);
		m1.setGroupsToVisit(groupsToVisit);
		session.persist(m1);	
		
		
		
		Member m2 = new Member();
		m2.setFirstName("Dieter");
		m2.setLastName("Nuhr");
		Set<JavaUserGroup> groupsToVisit3 = new HashSet<JavaUserGroup>();
		groupsToVisit3.add(jug1);
		m2.setGroupsToVisit(groupsToVisit3);
		session.persist(m2);
		
		session.flush();
		session.getTransaction().commit();
		session.clear();
		
		Assert.assertEquals(2, session.createCriteria(JavaUserGroup.class).list().size());
		Assert.assertEquals(2, session.createCriteria(Member.class).list().size());
		
		List<Member> allMembers = (List<Member>)session.createCriteria(Member.class).list();
		for (Member member : allMembers) {
			if( "Nuhr".equals(member.getLastName() ) ) {
				Assert.assertEquals(1, member.getGroupsToVisit().size());
				JavaUserGroup userGroupOfNuhr = member.getGroupsToVisit().toArray(new JavaUserGroup[1])[0];
				Set<Member> members = userGroupOfNuhr.getMembers();
				Assert.assertEquals(2, members.size());
			} else if( "Modsching".equals(member.getLastName()) ) {
				Assert.assertEquals(2, member.getGroupsToVisit().size());
			}
			else
				fail("Unknown member: " + member.getLastName());
		}
		
	}

}
