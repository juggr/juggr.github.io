package de.dser.demo.hibernate.model;

import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Before;

import de.dser.demo.hibernate.SessionFactoryProvider;

public class DatabaseTestBase {
	protected SessionFactory buildSessionFactory;
	@Before
	public void setup() {
		buildSessionFactory = new SessionFactoryProvider().buildSessionFactory();
	}
	@After
	public void teardown() {
		if( buildSessionFactory != null )
			buildSessionFactory.close();
	}
}
