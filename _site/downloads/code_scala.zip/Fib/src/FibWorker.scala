import scala.actors.Actor

class FibWorker(limit: Long) extends Actor {

  start
  
  def act() {
    loop {
      react {
        case n: Long => {
          if(n < limit) {
            reply(Fib.fib(n))
          } else {
            val worker1 = new FibWorker(limit)
            val worker2 = new FibWorker(limit)
            
            val future1 = worker1 !! (n-1)
            val future2 = worker2 !! (n-2)
            
            val result1 = future1().asInstanceOf[Long]
            val result2 = future2().asInstanceOf[Long]
            
            reply(result1 + result2)
          }
        }
      }
    }
  }
  
}