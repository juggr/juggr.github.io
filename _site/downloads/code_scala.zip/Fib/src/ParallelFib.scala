object ParallelFib {
  def fib(n: Long): Long = {
    val master = new FibWorker(40)
    val result = master !? n
    result.asInstanceOf[Long]
  }
}