import org.scalatest.junit.JUnitSuite
import org.scalatest.junit.ShouldMatchersForJUnit
import org.junit.Test

class FibTest extends JUnitSuite with ShouldMatchersForJUnit {

  @Test
  def testFib0() {
    Fib.fib(0) should be(0)
  }
  
  @Test
  def testFib1() {
    Fib.fib(1) should be(1)
  }
  
  @Test
  def testFib42() {
    Fib.fib(42) should be(267914296)
  }
  
  @Test
  def testParallelFib42() {
    ParallelFib.fib(42) should be(267914296)
  }
}