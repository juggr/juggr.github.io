object Mergesort {

  def sort(ls: List[Int]): List[Int] = ls match {
    case List() => List()
    case List(_) => ls
    case _ => {
      val (left, right) = ls.splitAt(ls.length / 2)
      val leftSorted = sort(left)
      val rightSorted = sort(right)
      
      merge(leftSorted, rightSorted)
    }
  }
  
  private def merge(left: List[Int], right: List[Int]): List[Int] = {
    if(left.isEmpty) right
    else if(right.isEmpty) left
    else {
      val x = left.first
      val y = right.first
      
      if(x < y) {
        x :: merge(left.tail, right)
      } else {
        y :: merge(left, right.tail)
      }
    }
  }
}