import org.scalatest.junit.JUnitSuite
import org.scalatest.junit.ShouldMatchersForJUnit
import org.junit.Test

class MergesortTest extends JUnitSuite with ShouldMatchersForJUnit {

  @Test
  def testSortEmptyList() {
    Mergesort.sort(List()) should be(List())
  }

  @Test
  def testSort() {
    Mergesort.sort(List(10, 7, 1, 5, 9)) should be(List(1, 5, 7, 9, 10))
  }

}